<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'auth_pop3', language 'es_mx', version '4.0'.
 *
 * @package     auth_pop3
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['auth_pop3changepasswordurl_key'] = 'URL para cambio de contraseña';
$string['auth_pop3description'] = 'Este método utiliza un servidor POP3 para comprobar si el nombre_de_usuario y contraseña facilitados son válidos.';
$string['auth_pop3host'] = 'Dirección del servidor POP3. Use el número IP, no el nombre DNS.';
$string['auth_pop3host_key'] = 'Host';
$string['auth_pop3mailbox'] = 'Nombre de la bandeja de entrada con la que intentar una conexión. (normalmente INBOX)';
$string['auth_pop3mailbox_key'] = 'Bandeja de correo';
$string['auth_pop3notinstalled'] = 'No se puede utilizar autenticación POP3. El módulo IMAP de PHP no está instalado.';
$string['auth_pop3port'] = 'Puerto del Servidor (110 es el más habitual)';
$string['auth_pop3port_key'] = 'Puerto';
$string['auth_pop3type'] = 'Tipo de servidor. Si su servidor utiliza certificado de seguridad, escoja pop3cert.';
$string['auth_pop3type_key'] = 'Tipo';
$string['pluginname'] = 'Servidor POP3';
$string['privacy:metadata'] = 'El plugin de Autenticación por servidor POP3 no almacena ningun dato personal.';
