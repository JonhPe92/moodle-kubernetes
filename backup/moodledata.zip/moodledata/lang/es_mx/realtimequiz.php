<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'realtimequiz', language 'es_mx', version '4.0'.
 *
 * @package     realtimequiz
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['addanswers'] = 'Añadir espacio para 3 respuestas más';
$string['addingquestion'] = 'Añadiendo pregunta';
$string['addquestion'] = 'Añadir pregunta';
$string['allquestions'] = 'Regresar a resultados completos';
$string['allsessions'] = 'Todas las sesiones';
$string['alreadyanswered'] = 'Usted ya ha contestado esta pregunta';
$string['answer'] = 'Respuesta';
$string['answers'] = 'Respuestas';
$string['answersent'] = 'Respuesta enviada - esperando que termine la pregunta:';
$string['answertext'] = 'Texto de respuesta:';
$string['atleastoneanswer'] = 'Usted necesita cuando menos una respuesta';
$string['awaittime'] = 'Tiempo de espera AJAX';
$string['awaittimedesc'] = 'Esta configuración define la frecuencia en segundos para revisar la pregunta y los datos resultantes por la ventana del navegador del estudiante. Cuando un número elevado de participantes en el examen causa que se alente el servidor, este número debería de incrementarse, para reducir así el número de llamadas a datos simultáneas. El valor mínimo es de 1 segundo.';
$string['awaittimeerror'] = 'El valor no debería de ser menor de 1';
$string['backquiz'] = 'Regresar al examen en tiempo real';
$string['backresponses'] = 'Regresar a resultados completos';
$string['badcurrentquestion'] = 'Pregunta_actual mala:';
$string['badquizid'] = 'ID _del_examen malo:';
$string['badresponse'] = 'Respuesta inesperada del servidor -';
$string['badsesskey'] = 'Clave de sesión mala';
$string['checkdelete'] = '¿Está seguro de querer eliminar esta pregunta?';
$string['choosecorrect'] = 'Configurar esta respuesta como la correcta';
$string['choosesession'] = 'Elegir una sesión para mostrar';
$string['classresult'] = 'Resultados de la clase:';
$string['classresultcorrect'] = 'correcto';
$string['clicknext'] = 'Elija \'Siguiente\' cuando todos estén listos';
$string['correct'] = '¿Respuesta correcta?';
$string['correctnotblank'] = 'La respuesta correcta no puede estar vacía';
$string['cross'] = 'Respuesta equivocada';
$string['deletequestion'] = 'Eliminar pregunta';
$string['displaynext'] = 'A punto de mostrar la siguiente pregunta:';
$string['edit'] = 'Editar examen';
$string['editquestions'] = 'Editar las preguntas';
$string['editquestiontime'] = 'Tiempo para preguntas (0 = tiempo por defecto)';
$string['edittingquestion'] = 'Editando pregunta';
$string['errorquestiontext'] = 'Error: Usted no ha contestado la pregunta';
$string['eventeditpageviewed'] = 'Página de edición de examen-en-tiempo-real vista';
$string['eventresponsesviewed'] = 'Respuestas de examen-en-tiempo-real vistas';
$string['finalresults'] = 'Resultados finales';
$string['hideusers'] = 'Ocultar usuarios';
$string['httperror'] = 'Hubo un problema con la solicitud - status:';
$string['httprequestfail'] = 'Abandonando :( No se puede crear una instancia XMLHTTP';
$string['incorrectstatus'] = 'El examen tiene un status incorrecto: \\';
$string['invalidanswer'] = 'Número de respuesta inválido';
$string['joininstruct'] = 'Espere hasta que el profesor le diga antes de elegir aquí';
$string['joinquiz'] = 'Unirse al Examen';
$string['joinquizasstudent'] = 'unirse al examen como un estudiante';
$string['modulename'] = 'Examen en tiempo real';
$string['modulenameplural'] = 'Exámenes en tiempo real';
$string['next'] = 'Siguiente >>';
$string['nextquestion'] = 'Siguiente pregunta';
$string['noanswers'] = 'Aún sin respuestas';
$string['nocorrect'] = 'Sin respuesta \'correcta\'';
$string['noquestion'] = 'Respuesta mala - sin datos de pregunta:';
$string['nosessions'] = 'Este examen en tiempo real aún no ha sido intentado';
$string['notallowedattempt'] = 'Usted no tiene permitido intentar este examen';
$string['notauthorised'] = 'Usted no tiene autorizado controlar este examen';
$string['onecorrect'] = 'Error: Debe de haber exactamente una respuesta correcta';
$string['pluginadministration'] = 'Administración del examen en tiempo real';
$string['pluginname'] = 'Examen en tiempo real';
$string['prevquestion'] = 'Pregunta previa';
$string['privacy:metadata:realtimequiz_submitted'] = 'Detalles de una respuesta dada a una pregunta de examen en tiempo real';
$string['privacy:metadata:realtimequiz_submitted:answerid'] = 'La ID de la respuesta que fue seleccionada';
$string['privacy:metadata:realtimequiz_submitted:questionid'] = 'La ID de la pregunta que ha sido contestada';
$string['privacy:metadata:realtimequiz_submitted:sessionid'] = 'La ID de la sesión en donde se dió la respuesta';
$string['privacy:metadata:realtimequiz_submitted:userid'] = 'La ID del usuario que dió la respuesta';
$string['question'] = 'Pregunta';
$string['questiondelete'] = 'Eliminar pregunta {$a}';
$string['questionfinished'] = 'La pregunta terminó, esperando resultados';
$string['questionimage'] = 'Imagen (opcional):';
$string['questionmovedown'] = 'Mover pregunta {$a} hacia abajo';
$string['questionmoveup'] = 'Mover pregunta {$a} hacia arriba';
$string['questions'] = 'Preguntas';
$string['questionslist'] = 'Preguntas en este examen en tiempo real:';
$string['questiontext'] = 'Texto de pregunta:';
$string['questiontime'] = 'Tiempo por defecto para pregunta';
$string['questiontime_help'] = 'El tiempo por defecto (en segundos) para mostrar cada pregunta.<br /> Esto puede anularse para preguntas individuales.';
$string['quizfinished'] = 'No más preguntas';
$string['quiznotrunning'] = 'El examen no está corriendo en este momento - espere a que su profesor lo inicie';
$string['realtimequiz:addinstance'] = 'Añadir un nuevo examen en Tiempo Real';
$string['realtimequiz:attempt'] = 'Intentar un examen';
$string['realtimequiz:control'] = 'Iniciar / controlar un examen';
$string['realtimequiz:editquestions'] = 'Editar las preguntas para un examen';
$string['realtimequiz:seeresponses'] = 'Ver las respuestas a un examen';
$string['realtimequizintro'] = 'Introducción';
$string['realtimequizsettings'] = 'Configuraciones del examen en tiempo real';
$string['reconnectinstruct'] = 'El examen ya está corriendo - Usted puede conectarse a esta sesión y tomar control de él.';
$string['reconnectquiz'] = 'Reconectarse al examen';
$string['removeimage'] = 'Remover imagen';
$string['responses'] = 'Ver respuestas';
$string['resultcorrect'] = 'correcto.';
$string['resultoverall'] = 'correcto. General:';
$string['resultthisquestion'] = 'Esta pregunta:';
$string['saveadd'] = 'Guardar pregunta y añadir otra';
$string['scorestable'] = 'Tabla de puntuaciones';
$string['seeresponses'] = 'Ver las respuestas';
$string['sendinganswer'] = 'Enviando respuesta';
$string['servererror'] = 'El servidor regresó error:';
$string['sessions'] = 'Sesiones';
$string['showsession'] = 'Mostrar';
$string['showusers'] = 'Mostrar usuarios';
$string['startnewquiz'] = 'Iniciar nueva sesión de examen';
$string['startnewquizconfirm'] = '¿Está Usted absolutamente seguro de querer abandonar la sesión actualmente corriendo del examen y empezar una nueva?';
$string['startquiz'] = 'Iniciar examen';
$string['studentconnected'] = 'estudiante conectado';
$string['studentsconnected'] = 'estudiantes conectados';
$string['submissions'] = 'Envíos';
$string['teacherjoinquizinstruct'] = 'Use esto si desea intentar Usted mismo un examen <br />(Usted también necesitará iniciar/reconectarse al examen en una ventana separada)';
$string['teacherstartinstruct'] = 'Use esto para iniciar un examen para que lo tomen los alumnos<br />Use la caja de texto para definir un nombre para esta sesión (para ayudarle a identificarla cuando revise los resultados en fecha posterior).';
$string['teacherstartnewinstruct'] = 'Empezar una nueva sesión de examen y abandonar la que está corriendo actualmente.<br />¡Sea muy cuidadoso de revisar que la sesión actual no esté todavía en uso antes de hacer esto!<br />Si tiene dudas, mejor use el primer botón para reconectarse a la sesión actual.';
$string['tick'] = 'Respuesta correcta';
$string['timeleft'] = 'Tiempo restante para responder:';
$string['totals'] = 'Total acumulado';
$string['tryagain'] = '¿Quiere intentarlo de nuevo?';
$string['unknownrequest'] = 'Solicitud desconocida: \\';
$string['updatequestion'] = 'Guardar pregunta';
$string['view'] = 'Ver examen';
$string['waitfirst'] = 'Esperando a que se envíe la primera pregunta';
$string['waitstudent'] = 'Esperando a que los estudiantes se conecten';
$string['yourresult'] = 'Su resultado:';
